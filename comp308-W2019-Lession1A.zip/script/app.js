(function(){

    
    function Start(){
        let startValue = 0;
        console.log(`%cApp Started..${startValue}`,"font-size :20px;color: green;")
    }

    window.addEventListener("load",Start);
    console._commandLineAPI.clear();
})();